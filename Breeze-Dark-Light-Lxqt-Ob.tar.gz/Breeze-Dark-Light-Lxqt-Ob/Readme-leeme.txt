This is a complete theme for the Lxqt Linux desktop environment that conforms to Plasma colors in its Breeze Dark and Breeze Light versions.
Created by Joselp
You can download this theme and contribute with a small donation at: https://www.pling.com/p/2119028/

Installation:

The file contains the themes for Lxqt and its default window manager Openbox.

- Unzip folder.
- Inside you will find three folders "Breeze-Lxqt, "Breeze-Dark-Ob" and "Breeze-Light-Ob". The first one contains the Lxqt theme and color palette and the other two contain the themes for Openbox.

Theme for Lxqt:
- Copy the contents of the "Breeze-Lxqt" folder to the path "/home/user/.local/share/lxqt" (if the lxqt folder does not exist, create it first). Overwrite if necessary.
- Open the Lxqt Configuration Center, enter the "Appearance" section:
    - Load "Breeze-Dark" or "Breeze Light" color palette
    - Choose the icon theme corresponding to the light or dark theme.
    - Choose the theme "Breeze-Dark" or "Breeze Light"

Theme for Openbox
- Copy the complete folders "Breeze-Dark-Ob" and "Breeze-Light-Ob" to the path "home/youruser/themes" (if the folder does not exist, create it first).
- Open "Openbox Settings" and choose Breeze Dark or Light theme

desktop wallpaper
- Choose the "Wallpaper" image of your choice to complete the integration of the themes.

That's it, you should now have dark mode configured correctly throughout the Lxqt environment.


-------------------------------------------------------------------------------------------------------------------------------------------------------


Este es un tema completo para el entorno de escritorio de Linux Lxqt que se ajusta a los colores de Plasma en sus versiones Breeze Dark y Breeze Light.
Creado por Joselp
Puedes descargar este tema y colaborar con una pequeña donación en: https://www.pling.com/p/2119028/


Instalación:

El archivo contiene los temas para Lxqt y su gestor de ventanas por defecto Openbox.

- Descomprimir carpeta.
- Dentro encontrarás tres carpetas "Breeze-Lxqt, "Breeze-Dark-Ob" y "Breeze-Light-Ob". La primera contiene el tema y la paleta de colores de Lxqt y las otras dos contienen los temas para Openbox.

Tema para Lxqt:
- Copiar el contenido de la carpeta "Breeze-Lxqt" a la ruta "/home/tusuario/.local/share/lxqt" (si no existiera la carpeta lxqt crearla primero). Sobreescribir si fuera necesario.
- Abrir el Centro de Configuración de Lxqt, entrar en el apartado "Aspecto":
    - Cargar la paleta de colores "Breeze-Dark" o "Breeze Light"
    - Elegir el tema de iconos correspondiente al tema claro u oscuro.
    - Elegir el tema "Breeze-Dark" o "Breeze Light"

Tema para Openbox
- Copiar las carpeta completas "Breeze-Dark-Ob" y "Breeze-Light-Ob" a la ruta "home/tuusuario/themes" (si no existiera la carpeta, crearla primero).
- Abrir "Configuración de Openbox" y elegir el tema Breeze Dark o Light

Fondo de escritorio
- Escoger la imagen "Wallpaper" de tu elección para completar la integración de los temas.

Eso es todo, ahora deberías tener configurado correctamente el modo oscuro en todo el entorno de Lxqt.




